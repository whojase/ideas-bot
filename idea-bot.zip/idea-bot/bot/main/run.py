from aiogram import Bot, Dispatcher, types
import asyncio

from config import  TOKEN_API
from bot.handlers.main_handlers import router

bot = Bot(token = TOKEN_API)
dp = Dispatcher()
dp.include_router(router = router)

async def main():
    await bot.delete_webhook(drop_pending_updates = True)
    await dp.start_polling(bot)

if __name__ == '__main__':
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print('OFF')
