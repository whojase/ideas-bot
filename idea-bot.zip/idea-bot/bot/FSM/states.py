from aiogram.fsm.state import StatesGroup, State

class IdeaInput(StatesGroup):
    idea = State()

class AdminResponse(StatesGroup):
    answer_admin = State()