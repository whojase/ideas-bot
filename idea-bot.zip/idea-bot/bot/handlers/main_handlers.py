from aiogram import Bot
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram import Router
from aiogram.types import Message
from aiogram import F

from bot.FSM.states import IdeaInput, AdminResponse
from bot.main.config import ADMIN_ID

router = Router()

@router.message(CommandStart())
async def start(mes: Message, state: FSMContext):
    await state.set_state(IdeaInput.idea)
    await mes.answer('👋 Привет, я бот в котором ты можешь предложить идеи для канала. Отправь свою идею')

@router.message(IdeaInput.idea)
async def idea_input(mes: Message, state: FSMContext, bot: Bot):
    await state.update_data(idea = mes.text, user_id = mes.from_user.id)
    data = await state.get_data()
    await bot.send_message(ADMIN_ID, f'❗Новая идея от пользователя {mes.from_user.id}:\n{data['idea']}')
    await mes.answer('🙏 Спасибо, твою идею обязательно расмотрят и напишут ответ...')
    await state.set_state(AdminResponse.answer_admin)

@router.message(AdminResponse.answer_admin, F.from_user.id == ADMIN_ID)
async def admin_response(mes: Message, state: FSMContext, bot: Bot):
    data = await state.get_data()
    user_id = data['user_id']
    await bot.send_message(user_id, f'👁️ Ответ по вашей идеи:\n{mes.text}')
    await mes.answer('👏 Ответ был отправлен пользователю')
    await state.clear()